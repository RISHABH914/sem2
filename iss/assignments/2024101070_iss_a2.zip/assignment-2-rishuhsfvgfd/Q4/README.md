## Follow the File Structure and add Assumptions in this Readme file
i have assumed that while performing insertion in first and second part maintainaing the type of data that is present is not necessary therefore anything can be inserted in the fields like for account number there are three digits after AC but in one insertion i have inserted with only 2 digits

### for b part i am adding data to only some of the required fields and not all (leaving only 1 field) which contained array of objects
