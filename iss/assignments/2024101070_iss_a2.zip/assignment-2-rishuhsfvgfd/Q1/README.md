## Follow the File Structure and add Assumptions in this Readme file

1.  i will be printing all the data in next    lines and not in one line
2. also i am assuming that numbers are not supposed to be unique i.e if i print 2 once then if it appears again then also it will be printed 
for p1
    im assuming that there's no problem with printing prime number is reverse order as in say roll no is 2024101070
    so the sequence becomes 2,2,7 but i will be printing 7,2,2
    same with all the questions
    
for p5
    i am assuming that 0 is to be considered as a multiple of 2,3,5