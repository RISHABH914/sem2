## Follow the File Structure and add Assumptions in this Readme file

- Write Insights in insights.txt
- Write all queries in q3.sql

1. i manipulated the given csv file to incorporate the standard method of making a csv file
    i placed heading for the rows at the starting followed by the data
    i combined both the files to place maxmimum and minimum temperatures in one table with all data from 1995 to 2021
    i have also used an extra row which was for the year it wasn't necessary though since the date which would be filled in one row will be of same year

2. assuming insights implies anything useful so i have given five insights i liked
3. also i have directly written whatever values my script returned into a formatted english text as a summary for insight