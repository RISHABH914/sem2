## Follow the File Structure and add Assumptions in this Readme file
assumption
   1. i have combined all the json files into a list of dictionaries since the given json fie is in list format

   2. for part b i am printing only unqiue keys for the json file

   3. for part c i am printing all the keys at top and then the values corresponding to it as per the json files