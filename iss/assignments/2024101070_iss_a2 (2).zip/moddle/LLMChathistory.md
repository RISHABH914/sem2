
### q3
1.  prompt - what is the syntax for loading a csv file to database


### q4
1. prompt - how to insert a new data into a no sql collection with a field having date format (specifically how to give command to insert date format data)
2. prompt - how can i print something from mongodb
3. prompt - how to access any key/value inside some collection which has an array of objects