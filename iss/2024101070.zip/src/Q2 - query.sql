use lab3;
SELECT distinct Dname from department 