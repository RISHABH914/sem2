USE lab3;
SELECT Fname, Lname, Salary from employee;

SELECT distinct Dname from department 