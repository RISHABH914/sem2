use lab3;
select Fname, Lname, Salary from employee where Salary>30000;