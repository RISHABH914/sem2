use lab3;
select Pname, Pnumber from project where Plocation="Houston" ;