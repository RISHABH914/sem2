use lab3;
select Fname, Lname from employee where fname like "J%";