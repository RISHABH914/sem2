const fs = require('fs');
const filePath = 'file1.txt';

try {
    fs.appendFileSync(filePath, '\nThis is an append operation\n');
    console.log("Append operation completed.");
} catch (error) {
    console.error('Error appending to file:', error);
}