const fs = require('fs');
const filePath = 'file1.txt';

try {
    const data = fs.readFileSync(filePath, 'utf8');
    console.log(data);
} catch (error) {
    console.error('Error reading file:', error);
}