const fs = require('fs');
const filePath = 'file1.txt';

try {
    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        console.log("File deleted successfully.");
    } else {
        console.log("File does not exist.");
    }
} catch (error) {
    console.error('Error deleting file:', error);
}
