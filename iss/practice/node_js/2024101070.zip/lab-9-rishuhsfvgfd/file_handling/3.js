const fs = require('fs');
const filePath = 'file1.txt';

try {
    fs.writeFileSync(filePath, 'This is a write operation');
    console.log("Write operation completed.");
} catch (error) {
    console.error('Some error occurred while writing to file:', error);
}