const fs = require('fs');

const dirName = 'file_handling';

try {
    if (!fs.existsSync(dirName)) {
        fs.mkdirSync(dirName);
        console.log(`Directory '${dirName}' created successfully.`);
    } else {
        console.log(`Directory '${dirName}' already exists.`);
    }
} catch (error) {
    console.error('Error creating directory:', error);
}
